<?php
namespace Opencart\Admin\Controller\Extension\Module;

class SkinDesignerConfig extends \Opencart\System\Engine\Controller {
    public function index(): void {
        $this->load->language('extension/module/skin_designer');
        $this->document->setTitle($this->language->get('heading_title') . ' - Config');
        $this->load->model('setting/setting');

        if ($this->request->server['REQUEST_METHOD'] == 'POST' && $this->validate()) {
            $this->model_setting_setting->editSetting('module_skin_designer', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link('extension/module/skin_designer_config', 'user_token=' . $this->session->data['user_token']));
        }

        $data['module_skin_designer_status'] = $this->config->get('module_skin_designer_status');
        $data['action'] = $this->url->link('extension/module/skin_designer_config', 'user_token=' . $this->session->data['user_token']);
        $data['cancel'] = $this->url->link('extension/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/module/skin_designer_config', $data));
    }

    protected function validate(): bool {
        if (!$this->user->hasPermission('modify', 'extension/module/skin_designer_config')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }
        return !$this->error;
    }
}
