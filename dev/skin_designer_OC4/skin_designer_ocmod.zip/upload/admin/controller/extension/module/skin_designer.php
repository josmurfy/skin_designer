<?php
namespace Opencart\Admin\Controller\Extension\Module;

class SkinDesigner extends \Opencart\System\Engine\Controller {
    public function index(): void {
        $this->load->language('extension/module/skin_designer');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('extension/module/skin_designer');

        $data['skins'] = $this->model_extension_module_skin_designer->getSkins();
        $data['add_skin'] = $this->url->link('extension/module/skin_designer|add', 'user_token=' . $this->session->data['user_token']);

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/module/skin_designer', $data));
    }

    public function install(): void {
        $this->load->model('extension/module/skin_designer');
        $this->model_extension_module_skin_designer->install();
    }

    public function uninstall(): void {
        $this->load->model('extension/module/skin_designer');
        $this->model_extension_module_skin_designer->uninstall();
    }
}
