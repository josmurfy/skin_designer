<?php
// Heading
$_['heading_title'] = 'Skin Designer';

// Button
$_['button_add'] = 'Add Skin';
$_['button_save'] = 'Save';
$_['button_cancel'] = 'Cancel';

// Text
$_['text_success'] = 'Success: You have modified skins!';
$_['text_list'] = 'Skin List';
$_['text_no_results'] = 'No skins found.';
$_['entry_status'] = 'Status';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify this module!';
