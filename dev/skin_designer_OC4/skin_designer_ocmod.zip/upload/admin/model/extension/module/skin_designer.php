<?php
namespace Opencart\Admin\Model\Extension\Module;

class SkinDesigner extends \Opencart\System\Engine\Model {
    public function install(): void {
        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "skin_designer_theme` (
            `theme_id` varchar(64) NOT NULL,
            `version` varchar(10) NOT NULL,
            PRIMARY KEY (`theme_id`)
        ) ENGINE=MyISAM DEFAULT CHARSET=utf8;");

        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "skin_designer_skin` (
            `theme_id` varchar(64) NOT NULL,
            `skin_id` varchar(64) NOT NULL,
            `name` varchar(64) NOT NULL,
            `root_skin_id` varchar(64) NOT NULL,
            PRIMARY KEY (`theme_id`,`skin_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");

        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "skin_designer_skin_option` (
            `option` varchar(64) NOT NULL,
            `theme_id` varchar(64) NOT NULL,
            `skin_id` varchar(64) NOT NULL,
            `value` text NOT NULL,
            PRIMARY KEY (`option`,`theme_id`,`skin_id`)
        ) ENGINE=MyISAM DEFAULT CHARSET=utf8;");
    }

    public function uninstall(): void {
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "skin_designer_theme`;");
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "skin_designer_skin`;");
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "skin_designer_skin_option`;");
    }

    public function getSkins(): array {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "skin_designer_skin`");
        return $query->rows;
    }
}
