<?php
namespace Opencart\Admin\Controller\Extension\DebugLogger\Module;

class DebugLogger extends \Opencart\System\Engine\Controller {

    private const VERSION = '2.1.0';
    private array $error = [];

    public function index(): void {
        $this->load->language('extension/debug_logger/module/debug_logger');
        $this->load->model('extension/debug_logger/module/debug_logger');
        $this->load->model('extension/debug_logger/module/debug_logger_license');
        $this->load->model('setting/setting');

        $this->document->setTitle($this->language->get('heading_title'));

        if ($this->request->server['REQUEST_METHOD'] === 'POST' && $this->validate()) {
            $this->model_setting_setting->editSetting('module_debug_logger', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module'));
        }

        $tok = $this->session->data['user_token'];

        $data['breadcrumbs'] = [
            ['text' => $this->language->get('text_home'), 'href' => $this->url->link('common/dashboard', 'user_token=' . $tok)],
            ['text' => $this->language->get('text_extension'), 'href' => $this->url->link('marketplace/extension', 'user_token=' . $tok . '&type=module')],
            ['text' => $this->language->get('heading_title'), 'href' => $this->url->link('extension/debug_logger/module/debug_logger', 'user_token=' . $tok)],
        ];

        $data['error_warning'] = $this->error['warning'] ?? '';
        $data['success'] = $this->session->data['success'] ?? '';
        unset($this->session->data['success']);

        $data['is_pro'] = $this->model_extension_debug_logger_module_debug_logger_license->isPro();
        $data['free_limit'] = 50;

        $defaults = [
            'module_debug_logger_status' => '0',
            'module_debug_logger_admin_enable' => '1',
            'module_debug_logger_catalog_enable' => '0',
            'module_debug_logger_capture_console' => '1',
            'module_debug_logger_capture_network' => '0',
            'module_debug_logger_capture_screenshot' => '0',
            'module_debug_logger_require_comment' => '0',
            'module_debug_logger_max_reports' => '500',
            'module_debug_logger_severity_bug' => '1',
            'module_debug_logger_severity_warning' => '1',
            'module_debug_logger_severity_info' => '1',
            'module_debug_logger_license_key' => '',
            'module_debug_logger_email_enable' => '0',
            'module_debug_logger_email_to' => '',
            'module_debug_logger_email_bug' => '1',
            'module_debug_logger_email_warning' => '0',
            'module_debug_logger_email_info' => '0',
            'module_debug_logger_webhook_type' => '',
            'module_debug_logger_webhook_url' => '',
            'module_debug_logger_btn_color' => '#dc2626',
            'module_debug_logger_header_color' => '#1e293b',
            'module_debug_logger_accent_color' => '#3b82f6',
            'module_debug_logger_btn_position' => 'navbar',
            'module_debug_logger_btn_size' => 'medium',
        ];
        foreach ($defaults as $key => $default) {
            $data[$key] = $this->request->post[$key] ?? $this->config->get($key) ?? $default;
        }

        // Update check
        $data['current_version'] = self::VERSION;
        $data['check_update_url'] = html_entity_decode($this->url->link('extension/debug_logger/module/debug_logger.checkUpdate', 'user_token=' . $tok . '&flush=1'));
        $data['install_update_url'] = html_entity_decode($this->url->link('extension/debug_logger/module/debug_logger.installUpdate', 'user_token=' . $tok));

        // Appearance defaults for reset
        $data['default_btn_color'] = '#dc2626';
        $data['default_header_color'] = '#1e293b';
        $data['default_accent_color'] = '#3b82f6';
        $data['default_btn_position'] = 'navbar';
        $data['default_btn_size'] = 'medium';

        $data['total_reports'] = $this->model_extension_debug_logger_module_debug_logger->getTotalReports();
        $data['total_open'] = $this->model_extension_debug_logger_module_debug_logger->getTotalOpenReports();
        $data['total_admin'] = $this->model_extension_debug_logger_module_debug_logger->getTotalBySource('admin');
        $data['total_catalog'] = $this->model_extension_debug_logger_module_debug_logger->getTotalBySource('catalog');

        $data['github_repo'] = 'josmurfy/debug-logger-releases';
        $data['action'] = $this->url->link('extension/debug_logger/module/debug_logger', 'user_token=' . $tok);
        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $tok . '&type=module');
        $data['view_reports'] = $this->url->link('extension/debug_logger/module/debug_logger.reports', 'user_token=' . $tok);
        $data['clear_url'] = $this->url->link('extension/debug_logger/module/debug_logger.clearReports', 'user_token=' . $tok);

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/debug_logger/module/debug_logger', $data));
    }

    /**
     * AJAX: Check GitHub Releases for updates.
     * Caches result for 6 hours in oc_setting.
     */
    public function checkUpdate(): void {
        $this->load->language('extension/debug_logger/module/debug_logger');

        $json = [];
        $current = self::VERSION;
        $repo = 'josmurfy/debug-logger-releases';
        $cache_key = 'module_debug_logger_update_cache';
        $cache_ts_key = 'module_debug_logger_update_cache_ts';
        $flush = !empty($this->request->get['flush']);

        // Check cache (6h) — skip if flush requested
        if (!$flush) {
            $cached_ts = (int)$this->config->get($cache_ts_key);
            if ($cached_ts && (time() - $cached_ts) < 21600) {
                $cached = $this->config->get($cache_key);
                if ($cached) {
                    $json = json_decode($cached, true) ?: [];
                    $json['from_cache'] = true;
                    $this->response->addHeader('Content-Type: application/json');
                    $this->response->setOutput(json_encode($json));
                    return;
                }
            }
        }

        // Call GitHub API
        $url = 'https://api.github.com/repos/' . $repo . '/releases/latest';
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_HTTPHEADER => [
                'Accept: application/vnd.github.v3+json',
                'User-Agent: DebugLoggerOC4',
            ],
        ]);
        $response = curl_exec($ch);
        $http_code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($http_code !== 200 || !$response) {
            $json['error'] = true;
            $json['message'] = $this->language->get('text_update_error');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }

        $release = json_decode($response, true);
        $latest = ltrim($release['tag_name'] ?? '', 'vV');
        $download_url = '';
        foreach ($release['assets'] ?? [] as $asset) {
            if (str_ends_with($asset['name'], '.ocmod.zip')) {
                $download_url = $asset['browser_download_url'];
                break;
            }
        }

        $json = [
            'current_version' => $current,
            'latest_version'  => $latest,
            'has_update'      => version_compare($latest, $current, '>'),
            'download_url'    => $download_url,
            'changelog'       => $release['body'] ?? '',
            'published_at'    => $release['published_at'] ?? '',
            'html_url'        => $release['html_url'] ?? '',
            'from_cache'      => false,
        ];

        // Cache result
        $this->load->model('setting/setting');
        $this->model_setting_setting->editSetting('module_debug_logger_update', [
            $cache_key    => json_encode($json),
            $cache_ts_key => (string)time(),
        ]);

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    /**
     * AJAX: Download and install update from GitHub release asset.
     */
    public function installUpdate(): void {
        $this->load->language('extension/debug_logger/module/debug_logger');
        $this->response->addHeader('Content-Type: application/json');

        if (!$this->user->hasPermission('modify', 'extension/debug_logger/module/debug_logger')) {
            $this->response->setOutput(json_encode(['error' => true, 'message' => $this->language->get('error_permission')]));
            return;
        }

        $download_url = $this->request->get['download_url'] ?? '';
        if (!$download_url || !str_starts_with($download_url, 'https://github.com/josmurfy/')) {
            $this->response->setOutput(json_encode(['error' => true, 'message' => 'Invalid download URL']));
            return;
        }

        // Download ZIP to temp
        $tmp_file = tempnam(sys_get_temp_dir(), 'dl_update_') . '.zip';
        $ch = curl_init($download_url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 60,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_HTTPHEADER     => ['User-Agent: DebugLoggerOC4'],
        ]);
        $zip_data = curl_exec($ch);
        $http_code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($http_code !== 200 || !$zip_data || strlen($zip_data) < 1000) {
            @unlink($tmp_file);
            $this->response->setOutput(json_encode(['error' => true, 'message' => $this->language->get('text_install_download_error')]));
            return;
        }
        file_put_contents($tmp_file, $zip_data);

        // Extract ZIP
        $zip = new \ZipArchive();
        if ($zip->open($tmp_file) !== true) {
            @unlink($tmp_file);
            $this->response->setOutput(json_encode(['error' => true, 'message' => $this->language->get('text_install_extract_error')]));
            return;
        }

        $ext_dir = DIR_EXTENSION . 'debug_logger/';
        $tmp_extract = sys_get_temp_dir() . '/dl_update_extract_' . time() . '/';
        $zip->extractTo($tmp_extract);
        $zip->close();
        @unlink($tmp_file);

        // Copy files over existing extension
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($tmp_extract, \RecursiveDirectoryIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );

        $copied = 0;
        foreach ($iterator as $item) {
            $relative = str_replace($tmp_extract, '', $item->getPathname());
            $target = $ext_dir . $relative;
            if ($item->isDir()) {
                if (!is_dir($target)) {
                    mkdir($target, 0755, true);
                }
            } else {
                copy($item->getPathname(), $target);
                $copied++;
            }
        }

        // Cleanup temp extraction
        $this->rrmdir($tmp_extract);

        // Clear update cache
        $this->load->model('setting/setting');
        $this->model_setting_setting->editSetting('module_debug_logger_update', [
            'module_debug_logger_update_cache'    => '',
            'module_debug_logger_update_cache_ts'  => '0',
        ]);

        // Read new version from install.json
        $new_version = self::VERSION;
        $install_json = $ext_dir . 'install.json';
        if (is_file($install_json)) {
            $info = json_decode(file_get_contents($install_json), true);
            $new_version = $info['version'] ?? $new_version;
        }

        $this->response->setOutput(json_encode([
            'success'     => true,
            'message'     => sprintf($this->language->get('text_install_success'), $new_version),
            'new_version' => $new_version,
            'files_count' => $copied,
        ]));
    }

    private function rrmdir(string $dir): void {
        if (!is_dir($dir)) return;
        $items = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \RecursiveDirectoryIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($items as $item) {
            $item->isDir() ? rmdir($item->getPathname()) : unlink($item->getPathname());
        }
        rmdir($dir);
    }

    public function install(): void {
        $this->load->model('extension/debug_logger/module/debug_logger');
        $this->load->model('setting/event');

        $this->model_extension_debug_logger_module_debug_logger->createTable();
        $this->model_extension_debug_logger_module_debug_logger->upgrade();

        $this->model_setting_event->addEvent([
            'code' => 'debug_logger_admin',
            'description' => 'Debug Logger Admin Header',
            'trigger' => 'admin/view/common/header/after',
            'action' => 'extension/debug_logger/event/header.index',
            'status' => true,
            'sort_order' => 0,
        ]);
        $this->model_setting_event->addEvent([
            'code' => 'debug_logger_catalog',
            'description' => 'Debug Logger Catalog Header',
            'trigger' => 'catalog/view/common/header/after',
            'action' => 'extension/debug_logger/event/header.index',
            'status' => true,
            'sort_order' => 0,
        ]);
    }

    public function uninstall(): void {
        $this->load->model('extension/debug_logger/module/debug_logger');
        $this->load->model('setting/event');
        $this->load->model('setting/setting');

        $this->model_extension_debug_logger_module_debug_logger->dropTable();
        $this->model_setting_event->deleteEventByCode('debug_logger_admin');
        $this->model_setting_event->deleteEventByCode('debug_logger_catalog');
        $this->model_setting_setting->deleteSetting('module_debug_logger');
    }

    public function debugSave(): void {
        $this->response->addHeader('Content-Type: application/json');

        if (
            $this->request->server['REQUEST_METHOD'] !== 'POST'
            || !isset($this->session->data['user_token'])
            || !$this->config->get('module_debug_logger_status')
            || !$this->config->get('module_debug_logger_admin_enable')
        ) {
            $this->response->setOutput(json_encode(['error' => 'Forbidden']));
            return;
        }

        $this->load->model('extension/debug_logger/module/debug_logger');
        $this->load->model('extension/debug_logger/module/debug_logger_license');

        $severity = strtolower((string)($this->request->post['severity'] ?? 'bug'));
        if (!in_array($severity, ['bug', 'warning', 'info'])) {
            $severity = 'bug';
        }

        $screenshot = '';
        $is_pro = $this->model_extension_debug_logger_module_debug_logger_license->isPro();
        if ($is_pro && $this->config->get('module_debug_logger_capture_screenshot')) {
            if (!empty($this->request->post['screenshot'])) {
                $ss = (string)$this->request->post['screenshot'];
                if (strpos($ss, 'data:image/') === 0 && strlen($ss) < 4194304) {
                    $screenshot = $ss;
                } else {
                    $this->log->write('Debug Logger: screenshot rejected — prefix=' . substr($ss, 0, 30) . ' len=' . strlen($ss));
                }
            } else {
                $this->log->write('Debug Logger: screenshot enabled but empty in POST');
            }
        }

        $report_data = [
            'url' => substr((string)($this->request->post['url'] ?? ''), 0, 2048),
            'console_log' => substr((string)($this->request->post['console_log'] ?? ''), 0, 65535),
            'network_log' => substr((string)($this->request->post['network_log'] ?? ''), 0, 65535),
            'screenshot' => $screenshot,
            'comment' => substr((string)($this->request->post['comment'] ?? ''), 0, 4096),
            'severity' => $severity,
            'admin_user' => $this->user->isLogged() ? (string)$this->user->getUserName() : '',
            'source' => 'admin',
        ];

        $report_id = $this->model_extension_debug_logger_module_debug_logger->addReport($report_data);

        $max = $is_pro
            ? (int)($this->config->get('module_debug_logger_max_reports') ?? 500)
            : $this->model_extension_debug_logger_module_debug_logger_license->getMaxReports();
        if ($max > 0) {
            $this->model_extension_debug_logger_module_debug_logger->pruneOldest($max);
        }

        if ($is_pro) {
            $this->trySendEmail($report_id, $report_data);
            $this->trySendWebhook($report_id, $report_data);
        }

        $this->response->setOutput(json_encode(['success' => true, 'id' => $report_id]));
    }

    public function assignReport(): void {
        $this->response->addHeader('Content-Type: application/json');

        if ($this->request->server['REQUEST_METHOD'] !== 'POST' || !isset($this->session->data['user_token'])) {
            $this->response->setOutput(json_encode(['error' => 'Forbidden']));
            return;
        }

        $this->load->model('extension/debug_logger/module/debug_logger');
        $rid = (int)($this->request->post['report_id'] ?? 0);
        $uid = (int)($this->request->post['user_id'] ?? 0);

        $this->model_extension_debug_logger_module_debug_logger->assignReport($rid, $uid);
        $this->response->setOutput(json_encode(['success' => true]));
    }

    public function updateReport(): void {
        $this->response->addHeader('Content-Type: application/json');

        if ($this->request->server['REQUEST_METHOD'] !== 'POST' || !isset($this->session->data['user_token'])) {
            $this->response->setOutput(json_encode(['error' => 'Forbidden']));
            return;
        }

        $this->load->model('extension/debug_logger/module/debug_logger');
        $rid = (int)($this->request->post['report_id'] ?? 0);
        $field = (string)($this->request->post['field'] ?? '');
        $value = (string)($this->request->post['value'] ?? '');

        if ($field === 'comment') {
            $this->model_extension_debug_logger_module_debug_logger->updateComment($rid, $value);
        } elseif ($field === 'severity') {
            $this->model_extension_debug_logger_module_debug_logger->updateSeverity($rid, $value);
        } else {
            $this->response->setOutput(json_encode(['error' => 'Invalid field']));
            return;
        }

        $this->response->setOutput(json_encode(['success' => true]));
    }

    public function reports(): void {
        if (
            !isset($this->session->data['user_token'])
            || ($this->request->get['user_token'] ?? '') !== $this->session->data['user_token']
        ) {
            $this->response->redirect($this->url->link('common/login'));
            return;
        }

        $this->load->model('extension/debug_logger/module/debug_logger');
        $this->load->model('extension/debug_logger/module/debug_logger_license');
        $tok = $this->session->data['user_token'];
        $base_raw = str_replace('&amp;', '&', $this->url->link('extension/debug_logger/module/debug_logger.reports', 'user_token=' . $tok));
        $base_html = str_replace('&', '&amp;', $base_raw);
        $is_pro = $this->model_extension_debug_logger_module_debug_logger_license->isPro();

        if (isset($this->request->get['action'])) {
            $action = $this->request->get['action'];
            $rid = (int)($this->request->get['report_id'] ?? 0);

            if ($action === 'export' && $is_pro) {
                $format = $this->request->get['format'] ?? 'csv';
                $fs = isset($this->request->get['filter_status']) ? (int)$this->request->get['filter_status'] : -1;
                $this->exportReports($format, $fs, (string)($this->request->get['filter_source'] ?? ''));
                return;
            }

            switch ($action) {
                case 'open': $this->model_extension_debug_logger_module_debug_logger->setStatus($rid, 0); break;
                case 'close': $this->model_extension_debug_logger_module_debug_logger->setStatus($rid, 1); break;
                case 'delete': $this->model_extension_debug_logger_module_debug_logger->deleteReport($rid); break;
                case 'clear_all': $this->model_extension_debug_logger_module_debug_logger->clearAllReports(); break;
            }
            $qs = isset($this->request->get['filter_status']) ? '&filter_status=' . (int)$this->request->get['filter_status'] : '';
            $this->response->redirect($base_raw . $qs);
            return;
        }

        $filter_status = isset($this->request->get['filter_status']) ? (int)$this->request->get['filter_status'] : -1;
        $filter_source = (string)($this->request->get['filter_source'] ?? '');
        $results = $this->model_extension_debug_logger_module_debug_logger->getReports($filter_status, $filter_source);
        $total_open = $this->model_extension_debug_logger_module_debug_logger->getTotalOpenReports();
        $total = $this->model_extension_debug_logger_module_debug_logger->getTotalReports();
        $total_closed = $total - $total_open;

        $admin_users = $is_pro ? $this->model_extension_debug_logger_module_debug_logger->getAdminUsers() : [];
        $assign_url_raw = $is_pro ? str_replace('&amp;', '&', $this->url->link('extension/debug_logger/module/debug_logger.assignReport', 'user_token=' . $tok)) : '';
        $update_url_raw = str_replace('&amp;', '&', $this->url->link('extension/debug_logger/module/debug_logger.updateReport', 'user_token=' . $tok));

        $sev_colors = ['bug' => '#ef4444', 'warning' => '#f59e0b', 'info' => '#3b82f6'];
        $src_colors = ['admin' => '#6366f1', 'catalog' => '#10b981'];
        $cfg_url_html = str_replace('&', '&amp;', str_replace('&amp;', '&', $this->url->link('extension/debug_logger/module/debug_logger', 'user_token=' . $tok)));

        $h = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">';
        $h .= '<meta name="viewport" content="width=device-width,initial-scale=1">';
        $h .= '<title>Debug Logger - Reports</title>';
        $h .= '<style>';
        $h .= ':root{--bg:#0f172a;--card:#1e293b;--border:#334155;--text:#f1f5f9;--muted:#94a3b8}';
        $h .= '*{box-sizing:border-box}body{background:var(--bg);color:var(--text);font-family:system-ui,sans-serif;margin:0;padding:0}';
        $h .= '.container{max-width:1100px;margin:0 auto;padding:1.5rem 1rem}';
        $h .= '.page-header{display:flex;align-items:center;gap:.75rem;margin-bottom:1.5rem;flex-wrap:wrap}';
        $h .= '.page-header h1{margin:0;font-size:1.2rem;font-weight:700}';
        $h .= '.pro-badge{background:linear-gradient(135deg,#f59e0b,#eab308);color:#000;padding:.15rem .5rem;border-radius:4px;font-size:.65rem;font-weight:800;letter-spacing:.5px}';
        $h .= '.free-badge{background:#334155;color:#94a3b8;padding:.15rem .5rem;border-radius:4px;font-size:.65rem;font-weight:700}';
        $h .= '.toolbar{display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1rem;align-items:center}';
        $h .= '.filter-btn{background:var(--card);border:1px solid var(--border);border-radius:20px;padding:.35rem .9rem;font-size:.78rem;color:var(--muted);text-decoration:none}';
        $h .= '.filter-btn.active{background:#1e3a5f;color:#93c5fd;border-color:#3b82f6}';
        $h .= '.stats{font-size:.72rem;color:var(--muted)}';
        $h .= '.export-btn{background:#14532d;border:1px solid #15803d;border-radius:6px;padding:.3rem .75rem;font-size:.78rem;color:#86efac;text-decoration:none}';
        $h .= '.clear-all{background:#7f1d1d;border:1px solid #991b1b;border-radius:6px;padding:.3rem .75rem;font-size:.78rem;color:#fca5a5;text-decoration:none;margin-left:auto}';
        $h .= '.report-card{background:var(--card);border:1px solid var(--border);border-radius:8px;padding:1rem;margin-bottom:.75rem}';
        $h .= '.badge{display:inline-flex;align-items:center;gap:4px;padding:.2rem .6rem;border-radius:12px;font-size:.75rem;font-weight:600;color:#fff}';
        $h .= '.meta{display:flex;align-items:center;gap:.5rem;flex-wrap:wrap;margin-bottom:.5rem;font-size:.78rem}';
        $h .= '.url-row{font-size:.78rem;color:var(--muted);word-break:break-all;margin:.4rem 0;display:flex;align-items:baseline;gap:.5rem;flex-wrap:wrap}';
        $h .= '.route-tag{background:#1e3a5f;color:#60a5fa;padding:.1rem .5rem;border-radius:4px;font-size:.72rem;font-family:monospace;white-space:nowrap}';
        $h .= '.comment{background:#0f172a;border-left:3px solid #3b82f6;padding:.5rem .75rem;font-size:.8rem;border-radius:0 4px 4px 0;margin:.5rem 0;white-space:pre-wrap}';
        $h .= 'pre{background:#0f172a;border:1px solid var(--border);border-radius:6px;padding:.75rem;font-size:.72rem;overflow-x:auto;max-height:200px;margin:.5rem 0}';
        $h .= '.screenshot-thumb{max-width:300px;border-radius:6px;border:1px solid var(--border);margin:.5rem 0;cursor:pointer;transition:transform .15s}';
        $h .= '.screenshot-thumb:hover{transform:scale(1.03)}';
        $h .= '.ss-overlay{position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.95);display:flex;align-items:center;justify-content:center;padding:1rem}';
        $h .= '.ss-overlay img{width:96vw;height:auto;max-height:96vh;border-radius:6px;object-fit:contain}';
        $h .= '.ss-close{position:fixed;top:12px;right:16px;color:#fff;font-size:2.2rem;cursor:pointer;z-index:100000;background:rgba(0,0,0,.6);width:44px;height:44px;border-radius:50%;display:flex;align-items:center;justify-content:center;line-height:1;border:1px solid #475569}';
        $h .= '.assign-select{background:var(--bg);color:var(--text);border:1px solid var(--border);border-radius:4px;font-size:.75rem;padding:.2rem .4rem}';
        $h .= '.sev-select{background:var(--bg);color:var(--text);border:1px solid var(--border);border-radius:12px;font-size:.72rem;padding:.15rem .4rem;font-weight:600;cursor:pointer}';
        $h .= '.sev-select option{font-weight:600}';
        $h .= '.comment-section{margin:.5rem 0}';
        $h .= '.comment-display{background:#0f172a;border-left:3px solid #3b82f6;padding:.5rem .75rem;font-size:.8rem;border-radius:0 4px 4px 0;white-space:pre-wrap;cursor:pointer;position:relative}';
        $h .= '.comment-display:hover{border-left-color:#60a5fa}';
        $h .= '.comment-display:empty::after{content:"Click to add a comment...";color:#475569;font-style:italic}';
        $h .= '.comment-edit{width:100%;background:#0f172a;color:var(--text);border:1px solid #3b82f6;border-radius:4px;padding:.5rem .75rem;font-size:.8rem;font-family:inherit;resize:vertical;min-height:60px}';
        $h .= '.comment-actions{display:flex;gap:.4rem;margin-top:.3rem}';
        $h .= '.comment-actions button{padding:.2rem .6rem;border-radius:4px;font-size:.72rem;cursor:pointer;border:1px solid var(--border)}';
        $h .= '.btn-comment-save{background:#14532d;border-color:#15803d!important;color:#86efac}';
        $h .= '.btn-comment-cancel{background:var(--card);color:var(--muted)}';
        $h .= '.actions{display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.75rem;align-items:center}';
        $h .= '.btn{display:inline-flex;align-items:center;gap:4px;padding:.3rem .75rem;border-radius:6px;font-size:.78rem;text-decoration:none;border:1px solid}';
        $h .= '.btn-open{background:#14532d;border-color:#15803d;color:#86efac}';
        $h .= '.btn-close{background:#1e3a5f;border-color:#1d4ed8;color:#93c5fd}';
        $h .= '.btn-del{background:#7f1d1d;border-color:#991b1b;color:#fca5a5}';
        $h .= '.empty{text-align:center;padding:3rem;color:var(--muted)}';
        $h .= '.cfg-link{font-size:.78rem;color:var(--muted);text-decoration:none;margin-left:auto}';
        $h .= '.closed-card{opacity:.55}';
        $h .= '</style></head><body><div class="container">';

        $h .= '<div class="page-header">';
        $h .= '<h1>Debug Logger - Reports</h1>';
        $badge_class = $is_pro ? 'pro-badge' : 'free-badge';
        $badge_text = $is_pro ? 'PRO' : 'FREE';
        $h .= '<span class="' . $badge_class . '">' . $badge_text . '</span>';
        $h .= '<a href="' . $cfg_url_html . '" class="cfg-link">Settings</a>';
        $h .= '</div>';

        $h .= '<div class="toolbar">';
        $all_active = ($filter_status < 0 && !$filter_source) ? ' active' : '';
        $h .= '<a href="' . $base_html . '" class="filter-btn' . $all_active . '">All (' . $total . ')</a>';

        $open_active = ($filter_status === 0) ? ' active' : '';
        $h .= '<a href="' . $base_html . '&amp;filter_status=0" class="filter-btn' . $open_active . '">Open (' . $total_open . ')</a>';

        $closed_active = ($filter_status === 1 && !$filter_source) ? ' active' : '';
        $h .= '<a href="' . $base_html . '&amp;filter_status=1" class="filter-btn' . $closed_active . '">Closed (' . $total_closed . ')</a>';

        $admin_active = ($filter_source === 'admin') ? ' active' : '';
        $h .= '<a href="' . $base_html . '&amp;filter_source=admin" class="filter-btn' . $admin_active . '">Admin</a>';

        $catalog_active = ($filter_source === 'catalog') ? ' active' : '';
        $h .= '<a href="' . $base_html . '&amp;filter_source=catalog" class="filter-btn' . $catalog_active . '">Catalog</a>';

        $h .= '<span class="stats">Showing: ' . count($results) . '</span>';
        if ($is_pro) {
            $h .= '<a href="' . $base_html . '&amp;action=export&amp;format=csv" class="export-btn">CSV</a>';
            $h .= '<a href="' . $base_html . '&amp;action=export&amp;format=json" class="export-btn">JSON</a>';
        }
        if ($total > 0) {
            $h .= '<a href="' . $base_html . '&amp;action=clear_all" class="clear-all"';
            $h .= " onclick=\"return confirm('Delete ALL reports?')\">Clear All</a>";
        }
        $h .= '</div>';

        if (empty($results)) {
            $h .= '<div class="empty">No reports found.</div>';
        } else {
            foreach ($results as $row) {
                $sev = htmlspecialchars($row['severity']);
                $color = $sev_colors[$row['severity']] ?? '#ef4444';
                $src = $row['source'];
                $src_c = $src_colors[$src] ?? '#6b7280';
                $closed = (int)$row['status'] === 1;
                $rid = (int)$row['id'];
                $card_class = $closed ? 'report-card closed-card' : 'report-card';

                $h .= '<div class="' . $card_class . '">';
                $h .= '<div class="meta">';
                // Severity dropdown
                $h .= '<select class="sev-select" data-rid="' . $rid . '" style="color:' . $color . ';border-color:' . $color . '">';
                foreach (['bug' => '#ef4444', 'warning' => '#f59e0b', 'info' => '#3b82f6'] as $sv => $sc) {
                    $sel = ($sev === $sv) ? ' selected' : '';
                    $h .= '<option value="' . $sv . '" style="color:' . $sc . '"' . $sel . '>' . strtoupper($sv) . '</option>';
                }
                $h .= '</select>';
                $h .= '<span class="badge" style="background:' . $src_c . '">' . htmlspecialchars($src) . '</span>';
                if (!empty($row['admin_user'])) {
                    $h .= '<span style="color:var(--muted)">' . htmlspecialchars($row['admin_user']) . '</span>';
                }
                if ($is_pro && !empty($admin_users)) {
                    $assigned = (int)($row['assigned_to'] ?? 0);
                    $h .= '<select class="assign-select" data-rid="' . $rid . '">';
                    $h .= '<option value="0">-- Unassigned --</option>';
                    foreach ($admin_users as $u) {
                        $sel = ($assigned === (int)$u['user_id']) ? ' selected' : '';
                        $uname = htmlspecialchars($u['firstname'] . ' ' . $u['lastname']);
                        $h .= '<option value="' . (int)$u['user_id'] . '"' . $sel . '>' . $uname . '</option>';
                    }
                    $h .= '</select>';
                }
                $date_str = htmlspecialchars((string)($row['date_added'] ?? ''));
                $h .= '<span style="color:var(--muted);margin-left:auto">#' . $rid . ' &middot; ' . $date_str . '</span>';
                $h .= '</div>';

                if (!empty($row['url'])) {
                    $clean_url = html_entity_decode((string)$row['url'], ENT_QUOTES, 'UTF-8');
                    $route_str = '';
                    if (preg_match('/[?&]route=([^&]+)/', $clean_url, $rm)) {
                        $route_str = '<span class="route-tag">' . htmlspecialchars($rm[1]) . '</span> ';
                    }
                    $h .= '<div class="url-row">' . $route_str . '<a href="' . htmlspecialchars($clean_url) . '" target="_blank" style="word-break:break-all">' . htmlspecialchars($clean_url) . '</a></div>';
                }
                $comment_text = htmlspecialchars((string)($row['comment'] ?? ''));
                $comment_raw = addslashes(str_replace(["\r\n", "\r", "\n"], "\\n", (string)($row['comment'] ?? '')));
                $h .= '<div class="comment-section">';
                $h .= '<div class="comment-display" data-rid="' . $rid . '" onclick="dlEditComment(this)" title="Click to edit">' . nl2br($comment_text) . '</div>';
                $h .= '</div>';
                if (!empty($row['console_log']) && trim((string)$row['console_log'])) {
                    $h .= '<pre>' . htmlspecialchars($row['console_log']) . '</pre>';
                }
                if (!empty($row['network_log']) && trim((string)$row['network_log'])) {
                    $h .= '<details><summary style="cursor:pointer;font-size:.78rem;color:var(--muted)">Network log</summary>';
                    $h .= '<pre>' . htmlspecialchars($row['network_log']) . '</pre></details>';
                }
                if (!empty($row['screenshot'])) {
                    $ss_src = htmlspecialchars($row['screenshot']);
                    $h .= '<img class="screenshot-thumb" src="' . $ss_src . '" alt="Screenshot" onclick="dlShowSS(this.src)">';
                }

                $h .= '<div class="actions">';
                if ($closed) {
                    $h .= '<a href="' . $base_html . '&amp;action=open&amp;report_id=' . $rid . '" class="btn btn-open">Reopen</a>';
                } else {
                    $h .= '<a href="' . $base_html . '&amp;action=close&amp;report_id=' . $rid . '" class="btn btn-close">Close</a>';
                }
                $h .= '<a href="' . $base_html . '&amp;action=delete&amp;report_id=' . $rid . '"';
                $h .= " class=\"btn btn-del\" onclick=\"return confirm('Delete?')\">Delete</a>";
                $h .= '</div></div>';
            }
        }

        $h .= '<script>';
        // Screenshot lightbox
        $h .= 'function dlShowSS(src){';
        $h .= 'var d=document.createElement("div");d.className="ss-overlay";';
        $h .= 'd.innerHTML=\'<span class="ss-close">&times;</span><img src="\'+src+\'">\';';
        $h .= 'd.onclick=function(e){if(e.target!==d.querySelector("img"))d.remove()};';
        $h .= 'd.querySelector("img").onclick=function(e){e.stopPropagation();';
        $h .= 'window.open(src,"_blank")};';
        $h .= 'document.addEventListener("keydown",function kh(e){';
        $h .= 'if(e.key==="Escape"){d.remove();document.removeEventListener("keydown",kh)}});';
        $h .= 'document.body.appendChild(d)}';

        // Generic update function
        $update_safe = addslashes($update_url_raw);
        $h .= "\nvar _updateUrl='" . $update_safe . "';";
        $h .= 'function dlUpdate(rid,field,value,cb){';
        $h .= 'fetch(_updateUrl,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},';
        $h .= 'body:"report_id="+rid+"&field="+field+"&value="+encodeURIComponent(value)})';
        $h .= '.then(function(r){return r.json()}).then(function(j){if(cb)cb(j)});}';

        // Severity change
        $h .= "\n";
        $h .= 'document.querySelectorAll(".sev-select").forEach(function(sel){';
        $h .= 'sel.addEventListener("change",function(){';
        $h .= 'var c={bug:"#ef4444",warning:"#f59e0b",info:"#3b82f6"};';
        $h .= 'this.style.color=c[this.value]||"#ef4444";this.style.borderColor=c[this.value]||"#ef4444";';
        $h .= 'dlUpdate(this.dataset.rid,"severity",this.value);';
        $h .= '});});';

        // Inline comment editing
        $h .= "\n";
        $h .= 'function dlEditComment(el){';
        $h .= 'if(el.querySelector("textarea"))return;';
        $h .= 'var rid=el.dataset.rid,txt=el.innerText||"";';
        $h .= 'el.innerHTML="<textarea class=comment-edit>"+txtEsc(txt)+"</textarea>"';
        $h .= '+"<div class=comment-actions><button class=btn-comment-save onclick=dlSaveComment(this)>Save</button>"';
        $h .= '+"<button class=btn-comment-cancel onclick=dlCancelComment(this)>Cancel</button></div>";';
        $h .= 'var ta=el.querySelector("textarea");ta.focus();ta.setSelectionRange(ta.value.length,ta.value.length);}';

        $h .= 'function dlSaveComment(btn){';
        $h .= 'var wrap=btn.closest(".comment-display"),ta=wrap.querySelector("textarea");';
        $h .= 'var val=ta.value,rid=wrap.dataset.rid;';
        $h .= 'dlUpdate(rid,"comment",val,function(){';
        $h .= 'wrap.innerHTML=val?nl2br(txtEsc(val)):"";});';
        $h .= '}';

        $h .= 'function dlCancelComment(btn){';
        $h .= 'location.reload();}';

        // Utility helpers
        $h .= 'function txtEsc(s){var d=document.createElement("div");d.appendChild(document.createTextNode(s));return d.innerHTML;}';
        $h .= 'function nl2br(s){return s.replace(/\\n/g,"<br>");}';

        if ($is_pro && !empty($admin_users)) {
            $h .= "\n";
            $h .= 'document.querySelectorAll(".assign-select").forEach(function(sel){';
            $h .= 'sel.addEventListener("change",function(){';
            $assign_safe = addslashes($assign_url_raw);
            $h .= 'fetch("' . $assign_safe . '",{method:"POST",';
            $h .= 'headers:{"Content-Type":"application/x-www-form-urlencoded"},';
            $h .= 'body:"report_id="+this.dataset.rid+"&user_id="+this.value});';
            $h .= '});});';
        }
        $h .= '</script>';

        $h .= '</div></body></html>';
        $this->response->setOutput($h);
    }

    private function exportReports(string $format, int $filter_status, string $filter_source): void {
        $reports = $this->model_extension_debug_logger_module_debug_logger->getReports($filter_status, $filter_source);

        if ($format === 'json') {
            header('Content-Type: application/json; charset=utf-8');
            header('Content-Disposition: attachment; filename="debug_reports_' . date('Y-m-d_His') . '.json"');
            $clean = array_map(function ($r) {
                unset($r['screenshot']);
                return $r;
            }, $reports);
            echo json_encode($clean, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            exit;
        }

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="debug_reports_' . date('Y-m-d_His') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['ID', 'Date', 'Severity', 'Source', 'URL', 'User', 'Comment', 'Console Errors', 'Status']);
        foreach ($reports as $row) {
            fputcsv($out, [
                $row['id'],
                $row['date_added'] ?? '',
                $row['severity'],
                $row['source'],
                $row['url'],
                $row['admin_user'] ?? '',
                $row['comment'],
                $row['console_log'] ?? '',
                (int)($row['status'] ?? 0) === 1 ? 'Closed' : 'Open',
            ]);
        }
        fclose($out);
        exit;
    }

    private function trySendEmail(int $report_id, array $data): void {
        try {
            if (!$this->config->get('module_debug_logger_email_enable')) {
                return;
            }

            // Check severity filter — if none checked, send for all
            $sev = $data['severity'] ?? 'bug';
            $any_checked = $this->config->get('module_debug_logger_email_bug')
                        || $this->config->get('module_debug_logger_email_warning')
                        || $this->config->get('module_debug_logger_email_info');
            if ($any_checked && !$this->config->get('module_debug_logger_email_' . $sev)) {
                return;
            }

            $to = (string)$this->config->get('module_debug_logger_email_to');
            if (!$to || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
                $this->log->write('Debug Logger: email_to invalid or empty [' . $to . ']');
                return;
            }

            $subject = '[Debug Logger] ' . strtoupper($data['severity']) . ' Report #' . $report_id;
            $url_clean = html_entity_decode((string)($data['url'] ?? ''), ENT_QUOTES, 'UTF-8');
            // Extract internal route from URL
            $route = '';
            if (preg_match('/[?&]route=([^&]+)/', $url_clean, $m)) {
                $route = urldecode($m[1]);
            }

            $body  = "New debug report:\n\n";
            $body .= "ID:       #" . $report_id . "\n";
            $body .= "Severity: " . $data['severity'] . "\n";
            $body .= "Source:   " . ($data['source'] ?? 'admin') . "\n";
            if ($route) {
                $body .= "Route:    " . $route . "\n";
            }
            $body .= "URL:      " . $url_clean . "\n";
            $body .= "User:     " . ($data['admin_user'] ?? 'Guest') . "\n";
            $body .= "Date:     " . date('Y-m-d H:i:s') . "\n\n";
            if (!empty($data['comment'])) {
                $body .= "Comment:\n" . $data['comment'] . "\n\n";
            }
            if (!empty($data['console_log'])) {
                $body .= "Console:\n" . substr($data['console_log'], 0, 2000) . "\n";
            }

            // OC4 Mail: adaptor + options array
            $mail_option = [
                'parameter'     => $this->config->get('config_mail_parameter'),
                'smtp_hostname' => $this->config->get('config_mail_smtp_hostname'),
                'smtp_username' => $this->config->get('config_mail_smtp_username'),
                'smtp_password' => html_entity_decode((string)$this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8'),
                'smtp_port'     => (int)$this->config->get('config_mail_smtp_port'),
                'smtp_timeout'  => (int)$this->config->get('config_mail_smtp_timeout'),
            ];

            $mail = new \Opencart\System\Library\Mail($this->config->get('config_mail_engine') ?: 'mail', $mail_option);
            $mail->setTo($to);
            $mail->setFrom($this->config->get('config_email'));
            $mail->setSender(html_entity_decode((string)$this->config->get('config_name'), ENT_QUOTES, 'UTF-8'));
            $mail->setSubject($subject);
            $mail->setText($body);

            // Attach screenshot if present
            if (!empty($data['screenshot']) && strpos($data['screenshot'], 'data:image/') === 0) {
                $parts = explode(',', $data['screenshot'], 2);
                if (!empty($parts[1])) {
                    $decoded = base64_decode($parts[1]);
                    if ($decoded !== false) {
                        $tmp = tempnam(sys_get_temp_dir(), 'dl_ss_');
                        $ext = '.jpg';
                        $tmp_file = $tmp . $ext;
                        file_put_contents($tmp_file, $decoded);
                        $mail->addAttachment($tmp_file);
                    }
                }
            }

            $mail->send();

            // Cleanup temp file
            if (!empty($tmp_file) && is_file($tmp_file)) {
                @unlink($tmp_file);
            }
            if (!empty($tmp) && is_file($tmp)) {
                @unlink($tmp);
            }

            $this->log->write('Debug Logger: email sent to ' . $to . ' for report #' . $report_id);
        } catch (\Throwable $e) {
            $this->log->write('Debug Logger email error: ' . $e->getMessage());
        }
    }

    private function trySendWebhook(int $report_id, array $data): void {
        try {
            $type = (string)$this->config->get('module_debug_logger_webhook_type');
            $url = (string)$this->config->get('module_debug_logger_webhook_url');
            if (!$type || !$url || !filter_var($url, FILTER_VALIDATE_URL)) {
                return;
            }

            $payload = ($type === 'discord')
                ? $this->buildDiscordPayload($report_id, $data)
                : $this->buildSlackPayload($report_id, $data);

            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode($payload),
                CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
                CURLOPT_TIMEOUT => 5,
            ]);
            curl_exec($ch);
            curl_close($ch);
        } catch (\Throwable $e) {
            $this->log->write('Debug Logger webhook error: ' . $e->getMessage());
        }
    }

    private function buildSlackPayload(int $id, array $d): array {
        $emoji = ['bug' => ':beetle:', 'warning' => ':warning:', 'info' => ':information_source:'];
        $color = ['bug' => '#ef4444', 'warning' => '#f59e0b', 'info' => '#3b82f6'];
        $sev = $d['severity'] ?? 'bug';
        return [
            'text' => ($emoji[$sev] ?? '') . ' Debug Report #' . $id,
            'attachments' => [[
                'color' => $color[$sev] ?? '#6b7280',
                'fields' => [
                    ['title' => 'Severity', 'value' => strtoupper($sev), 'short' => true],
                    ['title' => 'Source', 'value' => ucfirst($d['source'] ?? 'admin'), 'short' => true],
                    ['title' => 'URL', 'value' => $d['url'] ?? '', 'short' => false],
                    ['title' => 'Comment', 'value' => $d['comment'] ?: '_No comment_', 'short' => false],
                ],
                'footer' => 'Debug Logger Pro',
                'ts' => time(),
            ]],
        ];
    }

    private function buildDiscordPayload(int $id, array $d): array {
        $color = ['bug' => 0xef4444, 'warning' => 0xf59e0b, 'info' => 0x3b82f6];
        $sev = $d['severity'] ?? 'bug';
        return [
            'embeds' => [[
                'title' => 'Debug Report #' . $id,
                'color' => $color[$sev] ?? 0x6b7280,
                'fields' => [
                    ['name' => 'Severity', 'value' => strtoupper($sev), 'inline' => true],
                    ['name' => 'Source', 'value' => ucfirst($d['source'] ?? 'admin'), 'inline' => true],
                    ['name' => 'URL', 'value' => $d['url'] ?? ''],
                    ['name' => 'Comment', 'value' => $d['comment'] ?: '_No comment_'],
                ],
                'timestamp' => date('c'),
                'footer' => ['text' => 'Debug Logger Pro'],
            ]],
        ];
    }

    public function clearReports(): void {
        if (
            !isset($this->session->data['user_token'])
            || ($this->request->get['user_token'] ?? '') !== $this->session->data['user_token']
        ) {
            $this->response->redirect($this->url->link('common/login'));
            return;
        }

        $this->load->language('extension/debug_logger/module/debug_logger');
        $this->load->model('extension/debug_logger/module/debug_logger');
        $this->model_extension_debug_logger_module_debug_logger->clearAllReports();

        $this->session->data['success'] = $this->language->get('text_success_clear');
        $this->response->redirect($this->url->link(
            'extension/debug_logger/module/debug_logger',
            'user_token=' . $this->session->data['user_token']
        ));
    }

    private function validate(): bool {
        if (!$this->user->hasPermission('modify', 'extension/debug_logger/module/debug_logger')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }
        return empty($this->error);
    }
}
