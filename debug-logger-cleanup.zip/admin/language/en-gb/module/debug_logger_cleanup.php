<?php
$_['heading_title'] = 'Debug Logger Cleanup';
