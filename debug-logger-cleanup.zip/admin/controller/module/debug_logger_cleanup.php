<?php
namespace Opencart\Admin\Controller\Extension\DebugLoggerCleanup\Module;

class DebugLoggerCleanup extends \Opencart\System\Engine\Controller {
    public function index(): void {
        $this->load->language('extension/debug_logger_cleanup/module/debug_logger_cleanup');
        $path = DIR_EXTENSION . 'debug_logger/';
        $exists = is_dir($path);
        $html = '<div class="container-fluid"><div class="alert alert-' . ($exists ? 'warning' : 'success') . '">';
        if ($exists) {
            $html .= '<i class="fa-solid fa-triangle-exclamation"></i> debug_logger/ directory still exists. Re-click Install (+) on this module to remove it.';
        } else {
            $html .= '<i class="fa-solid fa-circle-check"></i> debug_logger/ directory removed! You can now install Debug Logger fresh. Uninstall this cleanup utility when done.';
        }
        $html .= '</div></div>';
        $this->response->setOutput($html);
    }

    public function install(): void {
        // Delete the old debug_logger extension directory
        $path = DIR_EXTENSION . 'debug_logger/';
        if (is_dir($path)) {
            $this->rrmdir($path);
        }

        // Clean stale install record so OpenCart Installer doesn't block
        $this->db->query("DELETE FROM `" . DB_PREFIX . "extension_install` WHERE `code` = 'debug_logger'");
        // Clean stale extension registration
        $this->db->query("DELETE FROM `" . DB_PREFIX . "extension` WHERE `code` = 'debug_logger' AND `type` = 'module'");
        // Clean stale events
        $this->db->query("DELETE FROM `" . DB_PREFIX . "event` WHERE `code` = 'debug_logger'");
    }

    public function uninstall(): void {
        // Nothing to clean
    }

    private function rrmdir(string $dir): void {
        if (!is_dir($dir)) {
            return;
        }
        $it    = new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS);
        $files = new \RecursiveIteratorIterator($it, \RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($files as $file) {
            if ($file->isDir()) {
                @rmdir($file->getRealPath());
            } else {
                @unlink($file->getRealPath());
            }
        }
        @rmdir($dir);
    }
}
